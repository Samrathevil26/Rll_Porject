package Utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import steps.RegistrationStepDef;

public class Mylistner implements ITestListener {
	ExtentReports extentReports;
	ExtentTest extentTest;

	@Override
	public void onStart(ITestContext context) {
		ExtentSparkReporter sparkReporter = new ExtentSparkReporter(
				"C:\\Users\\91630\\selenium_s2\\Registration\\target\\report.html");
		extentReports = new ExtentReports();
		extentReports.attachReporter(sparkReporter);
		extentReports.setSystemInfo("Build", "test");
		extentReports.setSystemInfo("Browser", "Chrome");
		extentReports.setSystemInfo("Platform", "Windows");
		extentReports.setSystemInfo("User", "Gaurav");
	}

	@Override
	public void onTestStart(ITestResult result) {
		extentTest = extentReports.createTest(result.getMethod().getMethodName());
	}

	@Override
	public void onTestFailure(ITestResult result) {
		try {
			WebDriver driver = RegistrationStepDef.getDriver();
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			String path = "C:\\Users\\91630\\selenium_s2\\Registration\\target\\screenshots_" + System.currentTimeMillis() + ".png";
			File target = new File(path);
			FileUtils.copyFile(source, target);
			String targetPath = target.getAbsolutePath();

			extentTest.fail(result.getThrowable(),
					MediaEntityBuilder.createScreenCaptureFromPath(targetPath).build());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onFinish(ITestContext context) {
		extentReports.flush();
	}
}
