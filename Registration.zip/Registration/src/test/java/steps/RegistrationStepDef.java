package steps;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Pagefactory.Registerpage;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RegistrationStepDef {
	private static final Logger logger = LogManager.getLogger(RegistrationStepDef.class);

	private static WebDriver driver;
	private Registerpage registerPage;

	private static final String EXCEL_PATH = "C:\\Users\\91630\\selenium_s2\\Registration\\src\\test\\resources\\Register_TestData.xlsx";
	private static final String SHEET_NAME = "Sheet1";

	@Before
	public void setup() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Given("the user is on the home page")
	public void the_user_is_on_the_home_page() {
		registerPage = new Registerpage(driver);
		driver.get("https://demowebshop.tricentis.com/");
		logger.info("user is on the home page");
	}

	@When("the user clicks on the register link")
	public void the_user_clicks_on_the_register_link() {
		registerPage.clickRegister();
		logger.info("user is on the register page");
	}

	@And("the user selects gender")
	public void the_user_selects_gender() {
		registerPage.clickGender();
	}

	@When("the user enters First Name from Excel {int}")
	public void the_user_enters_first_name_from_excel(Integer RowNo) throws IOException {
		Object[][] excelData = readExcelData(EXCEL_PATH, SHEET_NAME);
		String firstName = excelData[RowNo][0].toString();
		registerPage.enterFirstName(firstName);
		logger.info("user enters first name");
	}

	@When("the user enters Last Name from Excel {int}")
	public void the_user_enters_last_name_from_excel(Integer RowNo) throws IOException {
		Object[][] excelData = readExcelData(EXCEL_PATH, SHEET_NAME);
		String lastName = excelData[RowNo][1].toString();
		registerPage.enterLastName(lastName);
		logger.info("user enters last name");
	}

	@When("the user enters email from Excel {int}")
	public void the_user_enters_email_from_excel(Integer RowNo) throws IOException {
		Object[][] excelData = readExcelData(EXCEL_PATH, SHEET_NAME);
		String email = excelData[RowNo][2].toString();
		registerPage.enterEmail(email);
		logger.info("user enters Email ID");
	}

	@When("the user enters password from Excel {int}")
	public void the_user_enters_password_from_excel(Integer RowNo) throws IOException {
		Object[][] excelData = readExcelData(EXCEL_PATH, SHEET_NAME);
		String password = excelData[RowNo][3].toString();
		registerPage.enterPassword(password);
		logger.info("user enters password");
	}

	@When("the user enters confirm password from Excel {int}")
	public void the_user_enters_confirm_password_from_excel(Integer RowNo) throws IOException {
		Object[][] excelData = readExcelData(EXCEL_PATH, SHEET_NAME);
		String confirmPassword = excelData[RowNo][4].toString();
		registerPage.enterConfirmPassword(confirmPassword);
		logger.info("user enters confirm password");
	}

	@And("the user clicks on register")
	public void the_user_clicks_on_register() throws InterruptedException {
		registerPage.clickRegisterButton();
		Thread.sleep(2000);
		try {
			String msg = null;
			msg = registerPage.getmessage(registerPage.confirmPasswordError);
			System.out.println(msg);
			logger.error(msg);

		} catch (org.openqa.selenium.NoSuchElementException e) {
			System.out.println("Password given matches");

		}

		try {
			String mailerror = null;
			mailerror = registerPage.getmessage(registerPage.mailerr);
			System.out.println(mailerror);
			logger.error(mailerror);

		} catch (org.openqa.selenium.NoSuchElementException e) {
			System.out.println("given email is valid");

		}
	}

	@Then("the registration should be successful or not")
	public void the_registration_should_be_successful_or_not() {
		
	    WebElement successMessageElement = driver.findElement(By.xpath("//div[@class='result']"));

	    assertTrue(successMessageElement.isDisplayed(), "Registration should be successful, but the success message is not displayed.");
	}

	private Object[][] readExcelData(String filePath, String sheetName) throws IOException {
		FileInputStream file = new FileInputStream(filePath);
		Workbook workbook = WorkbookFactory.create(file);
		Sheet sheet = workbook.getSheet(sheetName);

		int rowCount = sheet.getLastRowNum();
		int colCount = sheet.getRow(0).getLastCellNum();

		Object[][] data = new Object[rowCount][colCount];

		for (int i = 1; i <= rowCount; i++) {
			Row row = sheet.getRow(i);
			for (int j = 0; j < colCount; j++) {
				Cell cell = row.getCell(j);
				data[i - 1][j] = cell.toString();
			}
		}

		workbook.close();
		file.close();

		return data;
	}

	public static WebDriver getDriver() {
		
		return driver;
	}
	
	
}
